using namespace std;

#include "Branch-and-Price.h"
#include <functional>
#include <cmath>

ILOSTLBEGIN
 
 

 
BaP_ALG::BaP_ALG()
{
}

BaP_ALG::BaP_ALG(Basic_Data &BD)
{
	
	p_BD = &BD;

	
	MAX_CPU_TIME = 3600;

	
	G_UB = 66666666666;
	G_LB = 0;
	Total_Time = 0;
	PURE_TIME = 0;

	v_Berth_Plans.clear();
	v_Request_Plans.clear();
	v_Shuttle_Plans.clear();

	UB_Pass_Times = 10;
	Record_UB_Unchanged = 0;

	lastBranchIndex = 0;
	lastResult = true;

 
	Branch_List = {

 
		&BaP_ALG::Branch_V_Terminal,
		&BaP_ALG::Branch_S_TK1K2,
 

		&BaP_ALG::Branch_V_Mean_BerthingTime,
		&BaP_ALG::Branch_V_Mean_UnberthingTime,
 
		&BaP_ALG::Branch_R_Mean_L1,

		&BaP_ALG::Branch_V_Berth,

 

	};

	Branch_Num = Branch_List.size();
	Branch_Value = vector<int>(Branch_Num, 0);
	Branch_Times = vector<int>(Branch_Num, 0);

}

BaP_ALG::~BaP_ALG()
{
	p_BD = nullptr;
}
 
void BaP_ALG::Branch(BaP_Node * node, BaP_Node* &  Son_L, BaP_Node* & Son_R)
{
	

	

	

	cout << "��ʼBranch" << endl;

	Son_L = new BaP_Node(*node);

	Son_R = new BaP_Node(*node);

	Basic_Data & BD = *p_BD;

	bool whether_continue = true;

	clock_t start_time = clock();
 
#pragma region ������֧
			 
#pragma region ������ͷ 0
	if (whether_continue)
	{
		whether_continue = Branch_V_Terminal(node, Son_L, Son_R);
	}
#pragma endregion

#pragma region K1T1K2 1
	if (whether_continue)
	{
		whether_continue = Branch_S_TK1K2(node, Son_L, Son_R);
	}
#pragma endregion

#pragma region ����Meanʱ�� 2
	if (whether_continue)
	{
		whether_continue = Branch_V_Mean_BerthingTime(node, Son_L, Son_R);
	}
#pragma endregion

#pragma region �벴Meanʱ�� 3
	if (whether_continue)
	{
		whether_continue = Branch_V_Mean_UnberthingTime(node, Son_L, Son_R);
	}
#pragma endregion

#pragma region L1 Meanʱ�� 4
	if (whether_continue)
	{
		whether_continue = Branch_R_Mean_L1(node, Son_L, Son_R);
	}
#pragma endregion 

#pragma region ������λ  5
	if (whether_continue)
	{
		whether_continue = Branch_V_Berth(node, Son_L, Son_R);
	}
#pragma endregion

 
#pragma endregion

#pragma region ������
	if (whether_continue)
	{
		
		node->Fathomed = true;
		Son_L->Fathomed = true;
		Son_R->Fathomed = true;

		Integer_UB.push_back(node->Objective);

		if (node->Objective < G_UB)
		{
			G_UB = node->Objective;

#pragma region ����best result

			Best_Result.UB = node->Objective;
			Best_Result.Vessel_Plan_Index.clear();
			Best_Result.Request_Plan_Index.clear();
			Best_Result.Shuttle_Plan_Index.clear();
			Best_Result.Vessel_Plan_Index = node->v_Plan_Index;
			Best_Result.Request_Plan_Index = node->r_Plan_Index;
			Best_Result.Shuttle_Plan_Index = node->s_Plan_Index;

#pragma endregion

			Record_UB_Unchanged = 0;

		}
	}
#pragma endregion

	clock_t endtime = clock();
	double cpu_time = double(endtime - start_time) / CLOCKS_PER_SEC;
	Total_Time += cpu_time;

	cout << "��֧������branching time�� " << cpu_time << endl;

	
}
 
void BaP_ALG::Cal()
{
	CalCore();      
	CalResultSave(); 
}

