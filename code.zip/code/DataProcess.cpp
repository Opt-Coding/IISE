#pragma once
#include "DataProcess.h"
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#define mkdir(dir, mode) _mkdir(dir)
#else
#include <sys/stat.h>
#include <sys/types.h>
#endif

using namespace std;


DataProcess::DataProcess()
{
	cout << "���ݼ���..." << endl;
}

DataProcess::~DataProcess()
{
	cout << "�����������..." << endl;
	cout << "" << endl;
}

void DataProcess::Data_Read(Basic_Data &BD, string file_path)
{
	cout << "Data_File: " << file_path << endl;

	read_Parameter(BD, file_path);

	if (BD.Terminal_Num == 0)
	{
		cout << "���ݶ�ȡʧ��" << endl;
		return;
	}

	read_Request(BD, file_path);

	read_Terminal(BD, file_path);

	read_Shuttle(BD, file_path);

	read_Vessel_Handling(BD, file_path);

	read_Vessel(BD, file_path);

	read_Vessel_Transshipment(BD, file_path);

	

#pragma region ��M׼��

	IloNum all_penaly = 0;
	
	for (int v = 0; v < BD.Vessel_Num; v++)
	{
		auto max_itr1 = std::max_element(BD.v_Vessel[v].Penalty_Berthing.begin(),
			BD.v_Vessel[v].Penalty_Berthing.end());

		auto max_itr2 = std::max_element(BD.v_Vessel[v].Penalty_Unberthing.begin(),
			BD.v_Vessel[v].Penalty_Unberthing.end());

		all_penaly += (*max_itr1 + *max_itr2);
 

	}

	
	for (int r = 0; r < BD.Request_Num; r++)
	{
		all_penaly += (BD.v_Request[r].Demand * BD.Container_Handling_Cost);
	}

	
	all_penaly += BD.Shuttle_Num *
		(BD.Shuttle_Data.Fixed_Cost + BD.Shuttle_Data.Max_Cost);


	if (all_penaly == 0)
	{
		all_penaly += 1;
	}

 
	BD.M_Vessel_Penalty = vector<IloNum >(BD.Vessel_Num, all_penaly);
 
	
	BD.M_Request_Penalty = vector<IloNum >(BD.Request_Num, all_penaly);
	
	
 

	BD.M_Shuttle_Penalty = vector<vector<IloNum >>(BD.Terminal_Num);
	for (int k1 = 0; k1 < BD.Terminal_Num; k1++)
	{
		BD.M_Shuttle_Penalty[k1] = vector<IloNum  >(BD.Terminal_Num, all_penaly);
 
	}


#pragma endregion

}

void DataProcess::read_Parameter(Basic_Data &BD, string file_path)
{

	if (true)
	{


		string file_path1 = file_path + "Parameter.txt";

		ifstream infile;
		infile.open(file_path1);

		if (!infile.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}
		string _temp = "";



		infile >> _temp;
		infile >> BD.Terminal_Num;

		infile >> _temp;
		infile >> BD.Berth_Num;

		infile >> _temp;
		infile >> BD.Vessel_Num;

		infile >> _temp;
		infile >> BD.Request_Num;

		infile >> _temp;
		infile >> BD.Time_Num;

		infile >> _temp;
		infile >> BD.Shuttle_Num;

		infile >> _temp;
		infile >> BD.Container_Handling_Cost;

		infile.close();


#pragma region CHECK
		cout << " BD.Terminal_Num:" << BD.Terminal_Num << endl;
		cout << " BD.Berth_Num:" << BD.Berth_Num << endl;
		cout << " BD.Vessel_Num:" << BD.Vessel_Num << endl;
		cout << " BD.Request_Num:" << BD.Request_Num << endl;
		cout << " BD.Time_Num:" << BD.Time_Num << endl;
		cout << " BD.Shuttle_Num:" << BD.Shuttle_Num << endl;
		cout << " BD.Container_Handling_Cost:" << BD.Container_Handling_Cost << endl;
#pragma endregion
	}


	
	if (true)
	{


		string file_path1 = file_path + "Another_Parameter.txt";

		ifstream infile;
		infile.open(file_path1);

		if (!infile.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}
		string _temp = "";
		double _temp2 = 0;


		infile >> _temp;
		infile >> _temp2;

		infile >> _temp;
		infile >> _temp2;

		infile >> _temp;
		infile >> _temp2;

		infile >> _temp;
		infile >> _temp2;

		infile >> _temp;
		infile >> _temp2;

		infile >> _temp;
		infile >> _temp2;

		infile >> _temp;
		infile >> BD.Another_Container_Handling_Cost;

		infile.close();


#pragma region CHECK

		cout << " BD.Another_Container_Handling_Cost:" << BD.Another_Container_Handling_Cost << endl;
#pragma endregion
	}
}

void DataProcess::read_Request(Basic_Data &BD, string file_path)
{

	file_path = file_path + "Request.txt";

	ifstream infile;
	infile.open(file_path);

	if (!infile.is_open())
	{
		cout << "�Ҳ����ļ���" << endl;
	}
	string _temp = "";

	std::string line;

	
	while (std::getline(infile, line)) {
		std::istringstream iss(line);
		int num;
		std::vector<int> numbers;

		
		while (iss >> num) {
			numbers.push_back(num);
		}


		Request rq;
		rq.Index = numbers[0];
		rq.Demand = numbers[1];
		rq.Type = numbers[2];
		rq.Vessel1_Index = numbers[3];
		rq.Vessel2_Index = numbers[4];
		rq.O_Terminal = numbers[5];
		rq.D_Terminal = numbers[6];

		BD.v_Request.push_back(rq);
	}

	
	infile.close();


#pragma region CHECK
	for (int i = 0; i < BD.v_Request.size(); i++)
	{
		printf("request{%i}, demand {%i}, type{%i}, v1{%i}, v2{%i}, o{%i}, d{%i}\n",
			BD.v_Request[i].Index, BD.v_Request[i].Demand, BD.v_Request[i].Type,
			BD.v_Request[i].Vessel1_Index, BD.v_Request[i].Vessel2_Index,
			BD.v_Request[i].O_Terminal, BD.v_Request[i].D_Terminal);
	}
#pragma endregion

	

}

void DataProcess::read_Terminal(Basic_Data &BD, string file_path)
{

	file_path = file_path + "Terminal.txt";

	ifstream infile;
	infile.open(file_path);

	if (!infile.is_open())
	{
		cout << "�Ҳ����ļ���" << endl;
	}
	string _temp = "";



	std::string line;

	
	int index = 0;
	while (std::getline(infile, line)) {
		std::istringstream iss(line);
		int num;
		std::vector<int> numbers;

		
		while (iss >> num) {
			numbers.push_back(num);
		}



		Terminal tm;
		tm.Index = index;
		for (int iii = 0; iii < numbers.size(); iii++)
		{
			tm.v_Berth_Indexes.push_back(numbers[iii]);
		}
		BD.v_Terminal.push_back(tm);
		index += 1;
	}

	
	infile.close();


#pragma region CHECK
	for (int i = 0; i < BD.v_Terminal.size(); i++)
	{
		printf("Terminal{%i}, Berth :\n",
			BD.v_Terminal[i].Index);
		for (int iii = 0; iii < BD.v_Terminal[i].v_Berth_Indexes.size(); iii++)
		{
			cout << " " << BD.v_Terminal[i].v_Berth_Indexes[iii] << " ";
		}
		cout << "" << endl;
	}
#pragma endregion
	
}

void DataProcess::read_Shuttle(Basic_Data &BD, string file_path)
{
	Shuttle_Info & sv = BD.Shuttle_Data;

#pragma region SV Parameter
	if (true)
	{


		string parameter_path = file_path + "SV_Parameter.txt";

		ifstream infile1;
		infile1.open(parameter_path);

		if (!infile1.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}
		string _temp = "";

		infile1 >> _temp;
		infile1 >> sv.Handling_Time;

		infile1 >> _temp;
		infile1 >> sv.Capacity;

		infile1 >> _temp;
		infile1 >> sv.Fixed_Cost;


		infile1.close();
	}

	if (true)
	{


		string parameter_path = file_path + "Another_SV_Parameter.txt";

		ifstream infile1;
		infile1.open(parameter_path);

		if (!infile1.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}
		string _temp = "";
		double _Tenp2 = 0;
		infile1 >> _temp;
		infile1 >> _Tenp2;

		infile1 >> _temp;
		infile1 >> _Tenp2;

		infile1 >> _temp;
		infile1 >> sv.Another_Fixed_Cost;


		infile1.close();
	}
#pragma endregion

#pragma region SV Time
	string file_path2 = file_path + "SV_Time.txt";

	ifstream infile2;
	infile2.open(file_path2);

	if (!infile2.is_open())
	{
		cout << "�Ҳ����ļ���" << endl;
	}

	std::string line2;
	

	while (std::getline(infile2, line2)) {
		std::istringstream iss(line2);

		double num;
		std::vector<int> numbers;

		
		while (iss >> num) {
			numbers.push_back(num);

		}

		sv.v_IJ_Time.push_back(numbers);

	}

	
	infile2.close();
#pragma endregion

#pragma region SV Cost
	if (true)
	{


		string file_path3 = file_path + "SV_Cost.txt";

		ifstream infile3;
		infile3.open(file_path3);

		if (!infile3.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}

		std::string line3;
		

		while (std::getline(infile3, line3)) {
			std::istringstream iss(line3);

			double num;
			std::vector<int> numbers;

			
			while (iss >> num) {
				numbers.push_back(num);

			}

			sv.v_IJ_Cost.push_back(numbers);

		}

		
		infile3.close();

	}


	if (true)
	{


		string file_path3 = file_path + "Another_SV_Cost.txt";

		ifstream infile3;
		infile3.open(file_path3);

		if (!infile3.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}

		std::string line3;
		

		while (std::getline(infile3, line3)) {
			std::istringstream iss(line3);

			double num;
			std::vector<int> numbers;

			
			while (iss >> num) {
				numbers.push_back(num);

			}

			sv.Another_v_IJ_Cost.push_back(numbers);

		}

		
		infile3.close();

	}
#pragma endregion



#pragma region Min Max Time

	int min_time = 19950411;
	int max_time = 0;
	for (int i = 0; i < BD.Terminal_Num; i++)
	{
		for (int j = 0; j < BD.Terminal_Num; j++)
		{
			if (i != j)
			{
				if (min_time > BD.Shuttle_Data.v_IJ_Time[i][j])
				{
					min_time = BD.Shuttle_Data.v_IJ_Time[i][j];
				}
				if (max_time < BD.Shuttle_Data.v_IJ_Time[i][j])
				{
					max_time = BD.Shuttle_Data.v_IJ_Time[i][j];
				}
			}
		}
	}
	BD.Shuttle_Data.Min_Time = min_time;
	BD.Shuttle_Data.Max_Time = max_time;

#pragma endregion

#pragma region Min Max Cost

	int min_cost = 19950411;
	int max_cost = 0;
	for (int i = 0; i < BD.Terminal_Num; i++)
	{
		for (int j = 0; j < BD.Terminal_Num; j++)
		{
			if (i != j)
			{
				if (min_cost > BD.Shuttle_Data.v_IJ_Cost[i][j])
				{
					min_cost = BD.Shuttle_Data.v_IJ_Cost[i][j];
				}
				if (max_cost < BD.Shuttle_Data.v_IJ_Cost[i][j])
				{
					max_cost = BD.Shuttle_Data.v_IJ_Cost[i][j];
				}
			}
		}
	}
	BD.Shuttle_Data.Min_Cost = min_cost;
	BD.Shuttle_Data.Max_Cost = max_cost;

#pragma endregion

#pragma region CHECK

	cout << " sv.Handling_Time:" << sv.Handling_Time << endl;
	cout << " sv.Capacity:" << sv.Capacity << endl;
	cout << " sv.Fixed_Cost:" << sv.Fixed_Cost << endl;
	cout << " sv.Min_Time" << sv.Min_Time << endl;
	cout << " sv.Max_Time" << sv.Max_Time << endl;

	cout << "sv cost" << endl;
	for (int i = 0; i < BD.Terminal_Num; i++)
	{
		for (int j = 0; j < BD.Terminal_Num; j++)
		{
			cout << BD.Shuttle_Data.v_IJ_Cost[i][j] << " ";
		}
		cout << "" << endl;
	}

	cout << "sv time" << endl;
	for (int i = 0; i < BD.Terminal_Num; i++)
	{
		for (int j = 0; j < BD.Terminal_Num; j++)
		{
			cout << BD.Shuttle_Data.v_IJ_Time[i][j] << " ";
		}
		cout << "" << endl;
	}
#pragma endregion
	

}

void DataProcess::read_Vessel_Handling(Basic_Data &BD, string file_path)
{

	file_path = file_path + "Vessel_Handling.txt";

	ifstream infile;
	infile.open(file_path);

	if (!infile.is_open())
	{
		cout << "�Ҳ����ļ���" << endl;
	}
	string _temp = "";



	std::string line;

	
	while (std::getline(infile, line)) {
		std::istringstream iss(line);
		double num;
		std::vector<int> numbers;

		
		while (iss >> num) {
			numbers.push_back(num);
		}


		BD.v_Vessel_Berth_HandleTime.push_back(numbers);
	}

	
	infile.close();

	cout << "Handling " << endl;
#pragma region CHECK
	for (int i = 0; i < BD.Vessel_Num; i++)
	{
		for (int j = 0; j < BD.Berth_Num; j++)
		{
			cout << BD.v_Vessel_Berth_HandleTime[i][j] << " ";
		}
		cout << "" << endl;
	}
#pragma endregion

	
}

void DataProcess::read_Vessel(Basic_Data &BD, string file_path) {

	if (true)
	{

		string file_path1 = file_path + "Vessel.txt";

		ifstream infile;
		infile.open(file_path1);

		if (!infile.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}
		string _temp = "";


		std::string line;
		while (std::getline(infile, line))
		{
			std::istringstream iss(line);
			int num1, num2, num3;
			std::vector<int> v_terminal, v_berth, v_R1, v_R2, v_R3, v_R4;
			std::vector<int> v_p1, v_p2;

			
			if (!(iss >> num1 >> num2 >> num3)) {
				std::cerr << "Failed to read integers from line!" << std::endl;
				continue;
			}



			std::string temp;
			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			
			


			std::istringstream vec_stream1(temp.substr(0, temp.size()));
			int temp_num;
			while (vec_stream1 >> temp_num) {
				v_terminal.push_back(temp_num);
				if (vec_stream1.peek() == ',')
					vec_stream1.ignore();
			}



			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			std::istringstream vec_stream2(temp.substr(0, temp.size()));
			while (vec_stream2 >> temp_num) {
				v_berth.push_back(temp_num);
				if (vec_stream2.peek() == ',')
					vec_stream2.ignore();
			}



			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}

			if (temp == "-1")
			{
				cout << "û�н��ڶ���" << endl;
			}
			else
			{
				std::istringstream vec_stream3(temp.substr(0, temp.size()));
				while (vec_stream3 >> temp_num) {
					v_R1.push_back(temp_num);
					if (vec_stream3.peek() == ',')
						vec_stream3.ignore();
				}
			}




			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			if (temp == "-1")
			{
				cout << "û�г��ڶ���" << endl;
			}
			else
			{
				std::istringstream vec_stream4(temp.substr(0, temp.size()));
				while (vec_stream4 >> temp_num) {
					v_R2.push_back(temp_num);
					if (vec_stream4.peek() == ',')
						vec_stream4.ignore();
				}
			}




			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}

			if (temp == "-1")
			{
				cout << "û��ת���ն���" << endl;
			}
			else
			{
				std::istringstream vec_stream5(temp.substr(0, temp.size()));
				while (vec_stream5 >> temp_num) {
					v_R3.push_back(temp_num);
					if (vec_stream5.peek() == ',')
						vec_stream5.ignore();
				}


			}










			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			if (temp == "-1")
			{
				cout << "û��ת���Ͷ���" << endl;
			}
			else
			{
				std::istringstream vec_stream6(temp.substr(0, temp.size()));
				while (vec_stream6 >> temp_num) {
					v_R4.push_back(temp_num);
					if (vec_stream6.peek() == ',')
						vec_stream6.ignore();
				}


			}

			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			int temp_num2;
			std::istringstream vec_stream7(temp.substr(0, temp.size()));
			while (vec_stream7 >> temp_num2) {
				v_p1.push_back(temp_num2);
				if (vec_stream7.peek() == ',')
					vec_stream7.ignore();
			}


			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			std::istringstream vec_stream8(temp.substr(0, temp.size()));
			while (vec_stream8 >> temp_num2) {
				v_p2.push_back(temp_num2);
				if (vec_stream8.peek() == ',')
					vec_stream8.ignore();
			}


			

			
			


			Vessel v1;
			v1.Index = num1;
			v1.Original_Terminal = num2;
			v1.Arrival_Time = num3;


			v1.v_Terminal_Indexes = v_terminal;
			v1.v_Berth_Indexes = v_berth;
			v1.R1_Index = v_R1;
			v1.R2_Index = v_R2;
			v1.R3_Index = v_R3;
			v1.R4_Index = v_R4;

			v1.Penalty_Berthing = v_p1;
			v1.Penalty_Unberthing = v_p2;

			BD.v_Vessel.push_back(v1);
		}



		infile.close();
	}

	if (true)
	{

		string file_path1 = file_path + "Another_Vessel.txt";

		ifstream infile;
		infile.open(file_path1);

		if (!infile.is_open())
		{
			cout << "�Ҳ����ļ���" << endl;
		}
		string _temp = "";


		std::string line;
		while (std::getline(infile, line))
		{
			std::istringstream iss(line);
			int num1, num2, num3;
			std::vector<int> v_terminal, v_berth, v_R1, v_R2, v_R3, v_R4;
			std::vector<int> v_p1, v_p2;

			
			if (!(iss >> num1 >> num2 >> num3)) {
				std::cerr << "Failed to read integers from line!" << std::endl;
				continue;
			}



			std::string temp;
			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			
			


			std::istringstream vec_stream1(temp.substr(0, temp.size()));
			int temp_num;
			while (vec_stream1 >> temp_num) {
				v_terminal.push_back(temp_num);
				if (vec_stream1.peek() == ',')
					vec_stream1.ignore();
			}



			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			std::istringstream vec_stream2(temp.substr(0, temp.size()));
			while (vec_stream2 >> temp_num) {
				v_berth.push_back(temp_num);
				if (vec_stream2.peek() == ',')
					vec_stream2.ignore();
			}



			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}

			if (temp == "-1")
			{
				cout << "û�н��ڶ���" << endl;
			}
			else
			{
				std::istringstream vec_stream3(temp.substr(0, temp.size()));
				while (vec_stream3 >> temp_num) {
					v_R1.push_back(temp_num);
					if (vec_stream3.peek() == ',')
						vec_stream3.ignore();
				}
			}




			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			if (temp == "-1")
			{
				cout << "û�г��ڶ���" << endl;
			}
			else
			{
				std::istringstream vec_stream4(temp.substr(0, temp.size()));
				while (vec_stream4 >> temp_num) {
					v_R2.push_back(temp_num);
					if (vec_stream4.peek() == ',')
						vec_stream4.ignore();
				}
			}




			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}

			if (temp == "-1")
			{
				cout << "û��ת���ն���" << endl;
			}
			else
			{
				std::istringstream vec_stream5(temp.substr(0, temp.size()));
				while (vec_stream5 >> temp_num) {
					v_R3.push_back(temp_num);
					if (vec_stream5.peek() == ',')
						vec_stream5.ignore();
				}


			}










			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			if (temp == "-1")
			{
				cout << "û��ת���Ͷ���" << endl;
			}
			else
			{
				std::istringstream vec_stream6(temp.substr(0, temp.size()));
				while (vec_stream6 >> temp_num) {
					v_R4.push_back(temp_num);
					if (vec_stream6.peek() == ',')
						vec_stream6.ignore();
				}


			}

			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			int temp_num2;
			std::istringstream vec_stream7(temp.substr(0, temp.size()));
			while (vec_stream7 >> temp_num2) {
				v_p1.push_back(temp_num2);
				if (vec_stream7.peek() == ',')
					vec_stream7.ignore();
			}


			
			if (!(iss >> temp)) {
				std::cerr << "Failed to read vector!" << std::endl;
				continue;
			}
			std::istringstream vec_stream8(temp.substr(0, temp.size()));
			while (vec_stream8 >> temp_num2) {
				v_p2.push_back(temp_num2);
				if (vec_stream8.peek() == ',')
					vec_stream8.ignore();
			}


			BD.v_Vessel[num1].Another_Penalty_Berthing = v_p1;
			BD.v_Vessel[num1].Another_Penalty_Unberthing = v_p2;


		}



		infile.close();
	}

#pragma region Min Max Time
	for (int i = 0; i < BD.Vessel_Num; i++)
	{
		int min_time = 19950411;
		int max_time = 0;
		for (int j = 0; j < BD.Berth_Num; j++)
		{
			
			if (min_time > BD.v_Vessel_Berth_HandleTime[i][j])
			{
				min_time = BD.v_Vessel_Berth_HandleTime[i][j];
			}
			if (max_time < BD.v_Vessel_Berth_HandleTime[i][j])
			{
				max_time = BD.v_Vessel_Berth_HandleTime[i][j];
			}
		}

		BD.v_Vessel[i].Min_Time = min_time;
		BD.v_Vessel[i].Max_Time = max_time;

		
	}
#pragma endregion

	cout << "Vessel  " << endl;
#pragma region CHECK
	for (int i = 0; i < BD.Vessel_Num; i++)
	{
		printf("vessel {%i}  ��ʼ��ͷ {%i}������ʱ��{%i}, Min{%i}�� Max{%i}\n",
			i, BD.v_Vessel[i].Original_Terminal, BD.v_Vessel[i].Arrival_Time,
			BD.v_Vessel[i].Min_Time, BD.v_Vessel[i].Max_Time);


		cout << "  ������ͷ��" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].v_Terminal_Indexes.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].v_Terminal_Indexes[iii] << " ";
		}
		cout << "" << endl;



		cout << "  ������λ��" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].v_Berth_Indexes.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].v_Berth_Indexes[iii] << " ";
		}
		cout << "" << endl;



		cout << "  ���ڶ�����" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].R1_Index.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].R1_Index[iii] << " ";
		}
		cout << "" << endl;

		cout << "  ���ڶ�����" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].R2_Index.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].R2_Index[iii] << " ";
		}
		cout << "" << endl;


		cout << "  ת���ն�����" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].R3_Index.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].R3_Index[iii] << " ";
		}
		cout << "" << endl;


		cout << "  ת���Ͷ�����" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].R4_Index.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].R4_Index[iii] << " ";
		}
		cout << "" << endl;


		cout << "  �����ͷ���" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].Penalty_Berthing.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].Penalty_Berthing[iii] << " ";
		}
		cout << "" << endl;


		cout << "  �벴�ͷ���" << endl;
		for (int iii = 0; iii < BD.v_Vessel[i].Penalty_Unberthing.size(); iii++)
		{
			cout << " " << BD.v_Vessel[i].Penalty_Unberthing[iii] << " ";
		}
		cout << "" << endl;
	}
#pragma endregion

	

}

void DataProcess::read_Vessel_Transshipment(Basic_Data &BD, string file_path)
{

	file_path = file_path + "VV_Transhipment.txt";

	ifstream infile;
	infile.open(file_path);

	if (!infile.is_open())
	{
		cout << "�Ҳ����ļ���" << endl;
	}
	string _temp = "";
	std::string line;



	
	while (std::getline(infile, line)) {
		std::istringstream iss(line);
		double num;
		std::vector<int> numbers;

		
		while (iss >> num)
		{
			if (num == -1)
			{

			}
			else
			{
				numbers.push_back(num);
				if (iss.peek() == ',')
					iss.ignore();
			}

		}

		BD.v_Vessel_Vessel_Transship.push_back(numbers);
	}

	
	infile.close();

	cout << "Vessel_Vessel Transshipment " << endl;
#pragma region CHECK
	for (int i = 0; i < BD.Vessel_Num; i++)
	{
		cout << "Vessel " << i << "  : " << endl;
		for (int j = 0; j < BD.v_Vessel_Vessel_Transship[i].size(); j++)
		{
			cout << BD.v_Vessel_Vessel_Transship[i][j] << " ";
		}
		cout << "" << endl;
	}
#pragma endregion

	
}

void DataProcess::Result_Output(BaP_ALG & ALG, string file_name)
{

	const char* myChar = file_name.c_str();

	if (mkdir(myChar, 0777) == 0) {
		std::cout << "�ļ��д����ɹ�" << std::endl;
	}
	else {
		std::cout << "�ļ��д���ʧ��" << std::endl;
	}

	
#pragma region ��Ҫ���

	string file_name1 = file_name + "Main_Result.txt";
	ofstream file(file_name1);
	if (!file.is_open()) {
		cout << "�޷����ļ���" << endl;
		return;
	}
	if (ALG.Best_Result.Status == 2)
	{
		file << "Solution Status: Optimal" << endl;
		file << "CPU_Time: " << ALG.Best_Result.Cal_Time << endl;
		file << "Best_UB: " << std::fixed << ALG.Best_Result.UB << endl;
		file << "Best_LB: " << std::fixed << ALG.Best_Result.LB << endl;

	}
	else if (ALG.Best_Result.Status == 1)
	{
		file << "Solution Status: Feasible" << endl;
		file << "CPU_Time: " << ALG.Best_Result.Cal_Time << endl;
		file << "Best_UB: " << std::fixed << ALG.Best_Result.UB << endl;
		file << "Best_LB: " << std::fixed << ALG.Best_Result.LB << endl;
	}
	else if (ALG.Best_Result.Status == -1)
	{
		file << "Solution Status: Unfeasible" << endl;
		file << "CPU_Time: " << ALG.Best_Result.Cal_Time << endl;
		file << "Best_UB: " << std::fixed << ALG.Best_Result.UB << endl;
		file << "Best_LB: " << std::fixed << ALG.Best_Result.LB << endl;
	}
	else if (ALG.Best_Result.Status == 0)
	{
		file << "Solution Status: Unknown" << endl;
		file << "CPU_Time: " << ALG.Best_Result.Cal_Time << endl;
		file << "Best_UB: " << std::fixed << ALG.Best_Result.UB << endl;
		file << "Best_LB: " << std::fixed << ALG.Best_Result.LB << endl;
	}
	IloInt another_vessel_cost = 0;

	IloInt vessel_cost = 0;
	IloInt total_waiting = 0;
	IloInt total_changed_vessel = 0;
	for (int j = 0; j < ALG.Best_Result.Vessel_Plan_Index.size(); j++)
	{
		Berth_Plan & bp = ALG.v_Berth_Plans[ALG.Best_Result.Vessel_Plan_Index[j]];
		vessel_cost += bp.cost;

 


		total_waiting += bp.berthing_time - ALG.p_BD->v_Vessel[bp.vessel_index].Arrival_Time;

		if (bp.terminal_index != ALG.p_BD->v_Vessel[bp.vessel_index].Original_Terminal)
		{
			total_changed_vessel++;
		}
	}

	IloInt request_cost = 0;
	IloInt another_request_cost = 0;

	IloInt total_container = 0;
	IloInt total_changed_request = 0;

	for (int j = 0; j < ALG.Best_Result.Request_Plan_Index.size(); j++)
	{
		Request_Plan & rp = ALG.v_Request_Plans[ALG.Best_Result.Request_Plan_Index[j]];
		request_cost += rp.cost;
		another_request_cost += ALG.p_BD->Another_Container_Handling_Cost
			* ALG.p_BD->v_Request[rp.reqeust_index].Demand;

		if (rp.o_terminal != rp.d_terminal)
		{
			total_container += ALG.p_BD->v_Request[rp.reqeust_index].Demand;
			total_changed_request++;
		}
	}
	IloInt another_sv_cost = 0;
	IloInt sv_cost = 0;
	IloInt total_sv = 0;
	for (int i = 0; i < ALG.Best_Result.Shuttle_Plan_Index.size(); i++)
	{
		Shuttle_Plan & sp = ALG.v_Shuttle_Plans[ALG.Best_Result.Shuttle_Plan_Index[i]];
		sv_cost += sp.cost;
		another_sv_cost += ALG.p_BD->Shuttle_Data.Another_Fixed_Cost;
		another_sv_cost += ALG.p_BD->Shuttle_Data.Another_v_IJ_Cost[sp.o_terminal][sp.d_terminal];

		total_sv += 1;
	}


	file << "V_Cost: " << vessel_cost << endl;
	file << "R_Cost: " << request_cost << endl;
	file << "SV_Cost: " << sv_cost << endl;
	file << "Another_V_Cost: " << another_vessel_cost << endl;
	file << "Another_R_Cost: " << another_request_cost << endl;
	file << "Another_SV_Cost: " << another_sv_cost << endl;
	file << "Total_Another_Cost: " << (another_vessel_cost + another_request_cost + another_sv_cost) << endl;

	file << "Total_Waiting: " << total_waiting << endl;
	file << "Total_Container: " << total_container << endl;
	file << "Total_SV: " << total_sv << endl;
	file << "Total_Vessel: " << total_changed_vessel << endl;
	file << "Total_Request: " << total_changed_request << endl;
	file << "UB: " << endl;
	for (int i = 0; i < ALG.Integer_UB.size(); i++)
	{
		file << ALG.Integer_UB[i] << " ";
	}

	file.close();
	
#pragma endregion

	
#pragma region vessel plan

	string file_name2 = file_name + "Vessel_Plan.txt";
	ofstream file2(file_name2);
	if (!file2.is_open()) {
		cout << "�޷����ļ���" << endl;
		return;
	}

	for (int i = 0; i < ALG.p_BD->Vessel_Num; i++)
	{

		for (int j = 0; j < ALG.Best_Result.Vessel_Plan_Index.size(); j++)
		{
			Berth_Plan & bp = ALG.v_Berth_Plans[ALG.Best_Result.Vessel_Plan_Index[j]];

			if (bp.vessel_index == i)
			{
				file2 << "Vessel: " << i << ", Cost: " << bp.cost << endl;

				file2 << "O(" << ALG.p_BD->v_Vessel[i].Original_Terminal << ") ";
				file2 << "A(" << ALG.p_BD->v_Vessel[i].Arrival_Time << ") ";
				file2 << "W(" << (bp.berthing_time - ALG.p_BD->v_Vessel[i].Arrival_Time) << ") ";
				file2 << "T(" << bp.terminal_index << ") ";
				file2 << "B(" << bp.berth_index << ") ";
				file2 << "Z1(" << bp.berthing_time << ") ";
				file2 << "Z2(" << bp.unberting_time << ") ";

				file2 << endl;
			}
		}

	}

	file2.close();
	


#pragma endregion

#pragma region request plan

	string file_name3 = file_name + "Request_Plan.txt";
	ofstream file3(file_name3);
	if (!file3.is_open()) {
		cout << "�޷����ļ���" << endl;
		return;
	}

	for (int i = 0; i < ALG.p_BD->Request_Num; i++)
	{

		for (int j = 0; j < ALG.Best_Result.Request_Plan_Index.size(); j++)
		{
			Request_Plan & rp = ALG.v_Request_Plans[ALG.Best_Result.Request_Plan_Index[j]];
			if (rp.reqeust_index == i)
			{
				file3 << "Request: " << i << " Cost: " << rp.cost << endl;

				file3 << "d(" << ALG.p_BD->v_Request[i].Demand << ") ";
				file3 << "t(" << ALG.p_BD->v_Request[i].Type << ") ";

				file3 << "O(" << rp.o_terminal << ") ";
				file3 << "D(" << rp.d_terminal << ") ";
				file3 << "L1(" << rp.l1_time << ") ";
				file3 << "L2(" << rp.l2_time << ") ";

				for (int s = 0; s < ALG.p_BD->Time_Num; s++)
				{
					file3 << "Y" << s << "(" << rp.v_y_tij[s][rp.o_terminal][rp.d_terminal] << ") ";
				}

				file3 << endl;
			}
		}

	}

	file3.close();
	


#pragma endregion

#pragma region shuttle plan

	string file_name4 = file_name + "Shuttle_Plan.txt";
	ofstream file4(file_name4);
	if (!file4.is_open())
	{
		cout << "�޷����ļ���" << endl;
		return;
	}

	for (int i = 0; i < ALG.Best_Result.Shuttle_Plan_Index.size(); i++)
	{

		Shuttle_Plan & sp = ALG.v_Shuttle_Plans[ALG.Best_Result.Shuttle_Plan_Index[i]];

		file4 << "Shuttle plan  " << ALG.Best_Result.Shuttle_Plan_Index[i] << " Cost: " << sp.cost << endl;

		file4 << "F(" << ALG.p_BD->Shuttle_Data.Fixed_Cost << ") ";
		file4 << "V(" << (sp.cost - ALG.p_BD->Shuttle_Data.Fixed_Cost) << ") ";
		file4 << "C(" << ALG.p_BD->Shuttle_Data.Capacity << ") ";

		file4 << "O(" << sp.o_terminal << ") ";
		file4 << "D(" << sp.d_terminal << ") ";
		file4 << "B1(" << sp.fo_berth << ") ";
		file4 << "U1(" << sp.uo_time << ") ";
		file4 << "P1(" << sp.po_time << ") ";
		file4 << "B2(" << sp.fd_berth << ") ";
		file4 << "U2(" << sp.ud_time << ") ";
		file4 << "P2(" << sp.pd_time << ") ";

		file4 << endl;

	}

	file4.close();
	


#pragma endregion
 
 
	std::cout << "���д�뵽�ļ��ɹ�" << std::endl;

}

void Experiment::Random_Instance()
{


	
	vector<string> InstantName{ "test" };


	InstantName =
	{

		"Random_K2_B5_V12_I0",


	};

 
	string basic_path = "./data/Random/";


	for (int i_index = 0; i_index < InstantName.size(); i_index++)
	{

#pragma region ���ݶ�ȡ

		Basic_Data BD;
		DataProcess DP;

		string data_file_directory = basic_path;
		data_file_directory += InstantName[i_index] + "/";
		DP.Data_Read(BD, data_file_directory);
		
#pragma endregion

#pragma region  Branch and Price 


 
 
		BaP_ALG BaP(BD);
		BaP.Cal();
 

		
		string result_directory = basic_path;
		result_directory += InstantName[i_index] + "/";
		result_directory += "BaP_Result/";
		DP.Result_Output(BaP, result_directory);

		cout << "Instance: " << InstantName[i_index] << endl;
		printf("***********************************************************************************************\n");

#pragma endregion

		
	}



}

 