#pragma once
using namespace std;

#include <ilcplex/ilocplex.h>
#include <stdio.h>
#include <iostream>
#include<sstream>
#include <fstream>
#include <ctime>
#include <string>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <unordered_map>
#include<string>
#include <chrono>








struct Cal_Result
{
	

	
	int Status;
	double Cal_Time;
	double LB;

	
	double UB;
	vector<int> Vessel_Plan_Index;
	vector<int> Request_Plan_Index;
	vector<int> Shuttle_Plan_Index;

};


struct Global_Value
{
	
	vector<IloNum> Value_List;
	IloNum Return_LB();
	void Delete_Value(IloNum d_value);
	void Print_Value();
};

struct Berth_Plan
{
	int index;

	int used_time;

	IloInt cost;

	int vessel_index;
	int terminal_index;
	int berth_index;
	int berthing_time;
	int unberting_time;

	vector<IloBool> v_q_i;
	vector<IloBool> v_w_b;
	vector<IloBool> v_z1_t;
	vector<IloBool> v_z2_t;
	vector<vector<IloBool>> v_ov_bt;
};

struct Request_Plan
{
	int index;

	int used_time;

	IloInt cost;

	int reqeust_index;

	int o_terminal;
	int d_terminal;
	int l1_time;
	int l2_time;

	vector<vector<IloBool>> v_mr_ij;

	vector<IloBool> v_l1_t;
	vector<IloBool> v_l2_t;

	vector<vector<vector<IloBool>>> v_y_tij;

};

struct Shuttle_Plan
{
	int index;

	int used_time;

	IloInt cost;

	int o_terminal;
	int d_terminal;

	int fo_berth;
	int uo_time;
	int po_time;

	int fd_berth;
	int ud_time;
	int pd_time;

	vector<vector<IloBool>> v_ms_ij;
	vector<IloBool> v_fo_b;
	vector<IloBool> v_uo_t;
	vector<IloBool> v_po_t;

	vector<IloBool> v_fd_b;
	vector<IloBool> v_ud_t;
	vector<IloBool> v_pd_t;

	vector<vector<IloBool>> v_os_bt;
	

};

struct BaP_Dual
{
	int index;

	vector<IloNum> dual1_v;
	vector<vector<IloNum>> dual2_vv;

	vector<IloNum> dual3_r;

	vector<vector<vector<IloNum>>> dual4_vkr1;
	vector<vector<vector<IloNum>>> dual4_vkr4;

	vector<vector<vector<IloNum>>> dual5_vkr2;
	vector<vector<vector<IloNum>>> dual5_vkr3;

	vector<vector<IloNum>> dual6_vr1;
	vector<vector<IloNum>> dual6_vr4;

	vector<vector<IloNum>> dual7_vr2;
	vector<vector<IloNum>> dual7_vr3;


	vector<vector<IloNum>> dual8_bt;
	vector<vector<vector<IloNum>>> dual9_tij;
	
	vector<vector<vector<IloNum>>> dual10_tkk_lb;
	vector<vector<vector<IloNum>>> dual10_tkk_ub;

};







struct Terminal
{
	int Index;
	vector<int> v_Berth_Indexes;
};

struct Vessel
{
	int Index;
	int Original_Terminal;
	int Arrival_Time;
	vector<int> v_Terminal_Indexes;
	vector<int> v_Berth_Indexes;

	vector<int> R1_Index;
	vector<int> R2_Index;
	vector<int> R3_Index;
	vector<int> R4_Index;

	vector<int> Penalty_Berthing;
	vector<int> Penalty_Unberthing;

	vector<int> Another_Penalty_Berthing;
	vector<int> Another_Penalty_Unberthing;

	int Min_Time;
	int Max_Time;
};

struct Request
{
	int Index;
	int Demand;
	int Type;

	int Vessel1_Index;
	int Vessel2_Index;

	int O_Terminal;
	int D_Terminal;

};

struct Shuttle_Info
{
	int Handling_Time;
	int Capacity;
	int Fixed_Cost;
	int Another_Fixed_Cost;

	vector<vector<int>> v_IJ_Time;
	vector<vector<int>> v_IJ_Cost;


	vector<vector<int>> Another_v_IJ_Cost;

	int Min_Time;
	int Max_Time;

	int Max_Cost;
	int Min_Cost;


};

class Basic_Data
{

public:

	Basic_Data();
	~Basic_Data();

	int Terminal_Num;
	vector<Terminal> v_Terminal;

	int Berth_Num;
	vector<vector<int>> v_Vessel_Berth_HandleTime;

	int Vessel_Num;
	vector<Vessel> v_Vessel;
	vector<vector<int>> v_Vessel_Vessel_Transship;

	int Request_Num;
	vector<Request> v_Request;

	int Shuttle_Num;
	Shuttle_Info Shuttle_Data;

	int Time_Num;

	double Container_Handling_Cost;
	double Another_Container_Handling_Cost;


	int Berth2Terminal(int berth);

	int Request2Index(int request_index, int vessel_index);

	vector<IloNum > M_Vessel_Penalty;
	vector<IloNum > M_Request_Penalty;
	vector<vector<IloNum >> M_Shuttle_Penalty;



};






