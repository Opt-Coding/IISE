#pragma once
using namespace std;
# include "DataStructure.h"
# include "GlobalFunction.h"



typedef IloArray<IloBoolVarArray>  IloBoolVarArray2;
typedef IloArray<IloBoolVarArray2>  IloBoolVarArray3;
typedef IloArray<IloBoolVarArray3>  IloBoolVarArray4;

typedef IloArray<IloNumVarArray> IloNumVarArray2;
typedef IloArray<IloNumVarArray2> IloNumVarArray3;
typedef IloArray<IloNumVarArray3> IloNumVarArray4;

typedef IloArray<IloIntVarArray> IloIntVarArray2;
typedef IloArray<IloIntVarArray2> IloIntVarArray3;
typedef IloArray<IloIntVarArray3> IloIntVarArray4;

typedef IloArray<IloRangeArray> IloRangeArray2;
typedef IloArray<IloRangeArray2> IloRangeArray3;
typedef IloArray<IloRangeArray3> IloRangeArray4;

IloNum Frac_Value(IloNum num);



struct BaP_Branch_Info
{
	

 
	vector<vector<int>> Vessel_Terminal;
	vector<vector<int>> Vessel_Berth;
 
	vector<vector<int>> Vessel_BerthingTime;
	vector<vector<int>> Vessel_UnberthingTime;
	vector<IloNum> Vessel_BerthingTime_UB;
	vector<IloNum> Vessel_BerthingTime_LB;
	vector<IloNum> Vessel_UnberthingTime_UB;
	vector<IloNum> Vessel_UnberthingTime_LB;


	vector<vector<vector<int>>> M_rij;
	vector<vector<int>> L1_rt;
	vector<IloNum> L1_UB;
	vector<IloNum> L1_LB;

	vector<vector<vector<int>>> MS_TK1K2_LB;
	vector<vector<vector<int>>> MS_TK1K2_UB;


};


struct Node_Vessel_Info
{
	
	int index;

	vector<int> Berth_List;

	vector<int> Berthing_Time_List;
	vector<int> Unberthing_Time_List;
 


};

struct Node_Request_Info
{
	
	int index;

	vector<int> O_List;
	vector<int> D_List;
	vector<int> T1_List;

	int whether_Transfer;

	vector<vector<int>> Banned_OD;

};

struct Node_SV_Info
{
	
	vector<vector<int>> Banned_B1T1;
	vector<vector<int>> Banned_B2T2;
};


struct BaP_Node
{
	

	
	BaP_Node(Basic_Data * p_BD);
	BaP_Node(const BaP_Node & RN);
	~BaP_Node();

	
	int Rank;
	Basic_Data * p_BD;

	
	BaP_Dual DUAL;

	
	BaP_Branch_Info  BI;
	vector<Node_Vessel_Info> v_Vessel_Info;
	vector<Node_Request_Info> v_Request_Info;
	Node_SV_Info Shuttle_Info; 

	
	vector<vector<IloNum>> RC_Vessel_Berth;
	vector<vector<IloNum>> RC_Vessel_T1;
	vector<vector<IloNum>> RC_Vessel_T2;
	vector<vector<vector<IloNum>>> RC_Request_OD;
	vector<vector<IloNum>> RC_Shuttle_B1T1;
	vector<vector<IloNum>> RC_Shuttle_B2T2;

	
	vector<int> Vessel_Plan_Set;
	vector<vector<int>> Each_Vessel_Plan_Set;
	vector<int> Request_Plan_Set;
	vector<vector<int>>  Each_Request_Plan_Set;
	vector<int> Shuttle_Plan_Set;
	vector<vector<vector<vector<int>>>> Each_K1K2T1_Shuttle_Plan_Set;

	
	vector<int> v_Plan_Index;
	vector<IloNum> v_Plan_Value;
	vector<int> r_Plan_Index;
	vector<IloNum> r_Plan_Value;
	vector<int> s_Plan_Index;
	vector<IloNum> s_Plan_Value;

	bool Whether_G;
	bool Fathomed;
	IloNum Objective;

};

 
struct Compare_BaP_Node
{
	bool operator()
		(const BaP_Node * a, const BaP_Node * b) const;
};

 

class BaP_ALG
{
	

public:
	using BranchFunc = bool(BaP_ALG::*)(BaP_Node*, BaP_Node*&, BaP_Node*&); 

	BaP_ALG();
	BaP_ALG(Basic_Data &BD);
	~BaP_ALG();

	void Cal();

	
	Basic_Data * p_BD;
	double MAX_CPU_TIME;

	
	IloNum G_UB;
	IloNum G_LB;
	Cal_Result Best_Result;

	
	double PURE_TIME;
	double Total_Time;


	
	Global_Value GV;

	vector<Berth_Plan> v_Berth_Plans;
	vector<Request_Plan> v_Request_Plans;
	vector<Shuttle_Plan> v_Shuttle_Plans;


	priority_queue<BaP_Node *,
		vector<BaP_Node *>,
		Compare_BaP_Node> Waiting_Nodes;

	vector<double> node_vessel_time;
	vector<double> node_request_time;
	vector<double> node_shuttle_time;

	vector<double> node_master_time;


	vector<IloNum> Integer_UB;

	vector<IloNum> Process_RC_Diff;

	int UB_Pass_Times;
	int Record_UB_Unchanged;



private:



 
	void Branch(BaP_Node * node, BaP_Node * &left_node, BaP_Node * & right_node);
 
	bool Branch_V_Terminal(BaP_Node * node, BaP_Node * &left_node, BaP_Node * & right_node);
	bool Branch_V_Berth(BaP_Node * node, BaP_Node * &left_node, BaP_Node * & right_node);
 
	bool Branch_V_Mean_BerthingTime(BaP_Node * node, BaP_Node * &left_node, BaP_Node * & right_node);
 
	bool Branch_V_Mean_UnberthingTime(BaP_Node * node, BaP_Node * &left_node, BaP_Node * & right_node);
 
	bool Branch_R_Mean_L1(BaP_Node * node, BaP_Node * &left_node, BaP_Node * & right_node);

	bool Branch_S_TK1K2(BaP_Node * node, BaP_Node * &left_node, BaP_Node * & right_node);

	void Node_Judge(BaP_Node * node);

	bool Node_VF(BaP_Node * node);

	void Node_Plan_Find(BaP_Node * p_node);

 
	void Global_UB();

 
	void Node_LB(BaP_Node * node);

	bool Node_Master(BaP_Node * node);
	
	bool Node_Master_BigM(BaP_Node * node);
 
	bool Node_Subproblem_Vessel(BaP_Node * node);

	bool Node_Subproblem_Request(BaP_Node * node);

	bool Node_Subproblem_Request0(BaP_Node * node, int request_index);

	bool Node_Subproblem_Request1(BaP_Node * node, int request_index);

	bool Node_Subproblem_Request2(BaP_Node * node, int request_index);

	bool Node_Subproblem_Shuttle(BaP_Node * node);

	bool Heur_Node_Subproblem_Vessel(BaP_Node * node);

	bool Heur_Node_Subproblem_Request(BaP_Node * node);

	bool Heur_Node_Subproblem_Request0(BaP_Node * node, int request_index);

	bool Heur_Node_Subproblem_Request1(BaP_Node * node, int request_index);

	bool Heur_Node_Subproblem_Request2(BaP_Node * node, int request_index);

	bool Heur_Node_Subproblem_Shuttle(BaP_Node * node);

	void Shuttle_Plan_Initial(BaP_Node * node);

	void Request_Plan_Initial(BaP_Node * node);

	void Vessel_Plan_Initial(BaP_Node * node);
 
 
	int lastBranchIndex;
	bool lastResult;

	vector<BranchFunc> Branch_List; 
	int Branch_Num; 
	vector<int> findIndicesExcludingIndex(const std::vector<int>& nums, int a); 
	vector<int> Branch_Value;
	vector<int> Branch_Times;

	void CalCore();
	void CalResultSave();

	BaP_Node * root;
	vector<BaP_Node*> All_Node;

};






