using namespace std;

# include "GlobalFunction.h"

int StrToInt(string str)
{
	int x;
	stringstream ss;
	ss << str;
	ss >> x;
	return x;
}
double StrToDouble(string str)
{
	double x;
	stringstream ss;
	ss << str;
	ss >> x;
	return x;
}



string DoubleToStr(double str)
{
	
	ostringstream  ss;
	ss << str;
	
	return ss.str();
}


string BoolToStr(bool str)
{
	
	ostringstream  ss;
	if (str)
	{
		ss << 1;
	}
	else
	{
		ss << 0;
	}

	
	return ss.str();
}

string IntToStr(int str)
{
	
	ostringstream  ss;
	ss << str;
	
	return ss.str();
}

vector <string> StrSplit(string str, const const char split)
{
	istringstream iss(str);    
	string token;            
	vector <string> v_str;
	while (getline(iss, token, split))    
	{
		
		v_str.push_back(token);
	}
	return v_str;
}


int TimeToSlot(double x, double temp_sail_time)
{
	


	double time_slot = x;
	double temp = temp_sail_time / time_slot;
	int slot = (int)(temp);
	if (temp - slot > 0)
	{
		slot++;
	}
	return slot;
}



std::vector<size_t> sort_indexes(const std::vector<double> &v) {
	
	std::vector<size_t> idx(v.size());
	
	std::iota(idx.begin(), idx.end(), 0);
	
	std::sort(idx.begin(), idx.end(), [&v](size_t i1, size_t i2) { return v[i1] < v[i2]; });
	return idx;
}



bool whetherInset(set<int> &mySet, int  target)
{
	if (mySet.find(target) != mySet.end()) {
		
		return true;
	}
	else {
		
		return false;
	}

}


bool STOP(double now_time, double time_limitation)
{
	if (now_time > time_limitation)
	{
		return true;
	}
	else
	{
		return false;
	}
}


bool Find_Int(vector<int> & list, int num)
{
	auto it = std::find(list.begin(), list.end(), num);

	
	if (it != list.end())
	{
		
		return true;
	}
	else {
		
		return false;
	}

}


vector<int> Sort_VectorINT(vector<int> nums)
{
	

	std::vector<std::pair<int, int>> indexedNums;

	
	for (int i = 0; i < nums.size(); ++i) {
		indexedNums.push_back(std::make_pair(nums[i], i));
	}

	
	std::sort(indexedNums.begin(), indexedNums.end());

	
	
	
	
	
	


	vector<int> list;
	
	for (const auto& pair : indexedNums) {
		

		list.push_back(pair.second);
	}

	return list;

}


vector<int> Sort_VectorDOUBLE(vector<double> nums)
{
	

	std::vector<std::pair<double, int>> indexedNums;

	
	for (int i = 0; i < nums.size(); ++i) {
		indexedNums.push_back(std::make_pair( nums[i], i));
	}

	
	std::sort(indexedNums.begin(), indexedNums.end());
 

	vector<int> list;
	
	for (const auto& pair : indexedNums) {
		

		list.push_back(pair.second);
	}

	return list;

}


