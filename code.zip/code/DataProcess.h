#pragma once
#include "DataStructure.h"
#include "GlobalFunction.h"
#include "Branch-and-Price.h"
#include <iostream>



using namespace std;
 
class DataProcess
{

public:
	DataProcess();
	~DataProcess();


 
	void Data_Read(Basic_Data &BD, string file_name = "./data/");
	void Result_Output(BaP_ALG & ALG, string file_name);

private:

	void read_Parameter(Basic_Data &BD, string file_path);
	void read_Request(Basic_Data &BD, string file_path);
	void read_Terminal(Basic_Data &BD, string file_path);
	void read_Shuttle(Basic_Data &BD, string file_path);


	void read_Vessel_Handling(Basic_Data &BD, string file_path); 
	void read_Vessel(Basic_Data &BD, string file_path);
	void read_Vessel_Transshipment(Basic_Data &BD, string file_path);



 
};


class Experiment
{
public:
	void Random_Instance();


};

