#pragma once
using namespace std;
# include <iostream>
# include <sstream>
# include <string>
# include <vector>
# include <Algorithm>
#include <algorithm>
#include <numeric>
#include<vector>
#include <iostream>
#include <set>
 
int StrToInt(string str);
double StrToDouble(string str);
string DoubleToStr(double str);
string IntToStr(int str);
string BoolToStr(bool str);


vector <string> StrSplit(string str, const const char split);
vector<size_t> sort_indexes(const std::vector<double> &v);
 
bool whetherInset(set<int> &mySet, int target);
 
bool STOP(double now_time, double time_limitation);

bool Find_Int(vector<int> & list, int num);

vector<int> Sort_VectorINT(vector<int> list);
 
vector<int> Sort_VectorDOUBLE(vector<double> nums);


  