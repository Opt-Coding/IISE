#include "DataStructure.h"
using namespace std;







Basic_Data::Basic_Data() {};
Basic_Data::~Basic_Data() {};


int Basic_Data::Berth2Terminal(int berth)
{

	for (int k = 0; k < Terminal_Num; k++)
	{
		for each (int b in v_Terminal[k].v_Berth_Indexes)
		{
			if (b == berth)
			{
				return k;
			}
		}
	}

}

int Basic_Data::Request2Index(int request_index, int vessel_index)
{
	

	for (int i = 0; i < v_Vessel[vessel_index].R1_Index.size(); i++)
	{
		if (v_Vessel[vessel_index].R1_Index[i] == request_index)
		{
			return i;
		}
	}

	for (int i = 0; i < v_Vessel[vessel_index].R2_Index.size(); i++)
	{
		if (v_Vessel[vessel_index].R2_Index[i] == request_index)
		{
			return i;
		}
	}

	for (int i = 0; i < v_Vessel[vessel_index].R3_Index.size(); i++)
	{
		if (v_Vessel[vessel_index].R3_Index[i] == request_index)
		{
			return i;
		}
	}

	for (int i = 0; i < v_Vessel[vessel_index].R4_Index.size(); i++)
	{
		if (v_Vessel[vessel_index].R4_Index[i] == request_index)
		{
			return i;
		}
	}

}
 
#pragma region ����ȫ���½�

IloNum Global_Value::Return_LB()
{
 
	auto min_it = std::min_element(Value_List.begin(), Value_List.end());
 
	std::cout << "Min value: " << *min_it << std::endl;
	IloNum min = (IloNum)*min_it;
	return min;
}

void Global_Value::Delete_Value(IloNum d_value)
{

	auto it = std::find(Value_List.begin(), Value_List.end(), d_value);
	if (it != Value_List.end()) {
		Value_List.erase(it);
	}
}

void Global_Value::Print_Value()
{
	cout << "�ִ���ֵ��";
	for (int i = 0; i < Value_List.size(); i++)
	{
		cout << Value_List[i] << " ";
	}
	cout << "" << endl;
}

#pragma endregion