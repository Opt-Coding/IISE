using namespace std;
#include "DataProcess.h"


int main(void *)
{
 
	Experiment EPM;
	EPM.Random_Instance();
  
	
	system("pause");
	return 0;

}
